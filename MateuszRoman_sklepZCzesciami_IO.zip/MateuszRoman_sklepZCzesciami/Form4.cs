﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MateuszRoman_sklepZCzesciami
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        int index = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <Form1.listCzesc.Count; i++)
            {
                Czesc.listCzesc[i].Write(listBox1, pictureBox1);
            }

            if (Czesc.listCzesc.Count==0)
            {
                MessageBox.Show("tu nic nie ma !!!");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            listBox1.Items.Clear();
            if (index >= Czesc.listCzesc.Count)
            {
                index = 0;
            }

            Czesc.listCzesc[index].Write(listBox1, pictureBox1);
                index++;
 
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            listBox1.Items.Clear();
           
            if (index <= 0)
            {
                index = Czesc.listCzesc.Count;
            }
            Czesc.listCzesc[index-1].Write(listBox1, pictureBox1);
            index--;
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                    while (!sr.EndOfStream)
                    {
                        string header = sr.ReadLine();
                        if (header == "== Czesc Zamienna ==")
                        {
                            new CzescZamienna(sr);
                        }
                        if (header == "== Akcesoria ==")
                        {
                            new Akcesoria(sr);
                        }
                    }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName))
                    foreach (Czesc rw in Czesc.listCzesc)
                        rw.Serialize(sw);
               
            }
               
        }
    }
}
