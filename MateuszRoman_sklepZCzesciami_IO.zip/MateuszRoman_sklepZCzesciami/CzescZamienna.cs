﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace MateuszRoman_sklepZCzesciami
{
    public class CzescZamienna: Czesc
    {
        protected int id;
        protected bool highQuality;
        protected bool used;
        protected int yearsOfWarranty;

        public CzescZamienna():base()
        {
            this.id = 0;
            this.highQuality = true;
            this.used = false;
            this.yearsOfWarranty = 0;


        }
        public CzescZamienna(string partName, string brandName, string model, int price, int ID, float engineCapacity, int yearOfProduction, bool serviceStation, string category, bool tenPercentDiscount, DateTime dOfPP, Bitmap photo, int id, bool highQuality, bool used, int yearsOfWarranty) : base(partName, brandName, model, price, ID, engineCapacity, yearOfProduction, serviceStation, category, tenPercentDiscount,dOfPP,photo)
        {
            this.id = id;
            this.highQuality = highQuality;
            this.used = used;
            this.yearsOfWarranty = yearsOfWarranty;

        }
        public CzescZamienna(CzescZamienna cx):base(cx)
        {

            this.id = cx.id;
            this.highQuality = cx.highQuality;
            this.used = cx.used;
            this.yearsOfWarranty = cx.yearsOfWarranty;
        }
        public CzescZamienna(StreamReader sr)
        {
            Deserialize(sr);
            listCzesc.Add(this);
        }


        override public void Write(ListBox lb,PictureBox pb)
        {
            base.Write( lb,pb);
            lb.Items.Add("ID2" + id);
            lb.Items.Add("High Quality: " + highQuality);
            lb.Items.Add("Used: " + used);
            lb.Items.Add("Years of warranty: " + yearsOfWarranty);
            lb.Items.Add("Markup: " + Markup(price) + " zl" );
            lb.Items.Add("Vat: " + Tax(price) + " zl" );


        }

        ~CzescZamienna()
        {

        }

        private int Markup(int price)
        {
            Random rnd = new Random();
            int w = rnd.Next(2, 5);
            return price * 1 / w;

        }

        private int Tax(int price)
        {
            return (price * 1 / 3) * 8 / 100;
        }
        private void SaveBmp(StreamWriter sw)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                photo.Save(ms, ImageFormat.Bmp);
                byte[] bytes = ms.ToArray();
                sw.WriteLine(Convert.ToBase64String(bytes, 0, bytes.Length));
            }
        }
        override public void Serialize(StreamWriter sw)
        {
           
            sw.WriteLine("== Czesc zamienna ==");
            sw.WriteLine(partName);
            sw.WriteLine(brandName);
            sw.WriteLine(model);
            sw.WriteLine(price);
            sw.WriteLine(ID);
            sw.WriteLine(engineCapacity);
            sw.WriteLine(yearOfProduction);
            sw.WriteLine(serviceStation);
            sw.WriteLine(category);
            sw.WriteLine(tenPercentDiscount);
            sw.WriteLine(dOfPP);
            sw.WriteLine(id);
            sw.WriteLine(highQuality);
            sw.WriteLine(used);
            sw.WriteLine(yearsOfWarranty);
            SaveBmp(sw);
        }


        override public void Deserialize(StreamReader sr)
        {
            
            partName = sr.ReadLine();
            brandName = sr.ReadLine();
            model = sr.ReadLine();
            price = Convert.ToInt32(sr.ReadLine());
            ID = Convert.ToInt32(sr.ReadLine());
            engineCapacity = Convert.ToInt32(sr.ReadLine());
            yearOfProduction= Convert.ToInt32(sr.ReadLine());
            serviceStation = Convert.ToBoolean(sr.ReadLine());
            category = sr.ReadLine();
            tenPercentDiscount = Convert.ToBoolean(sr.ReadLine());
            dOfPP = Convert.ToDateTime(sr.ReadLine());
            id = Convert.ToInt32(sr.ReadLine());
            highQuality = Convert.ToBoolean(sr.ReadLine());
            used = Convert.ToBoolean(sr.ReadLine());
            yearsOfWarranty = Convert.ToInt32(sr.ReadLine());
          
            photo = LoadBmp(sr);
        }

        private Bitmap LoadBmp(StreamReader sr)
        {
            byte[] bytes = Convert.FromBase64String(sr.ReadLine());
            using (MemoryStream ms = new MemoryStream(bytes))
                return new Bitmap(ms);
        }
    }
}
