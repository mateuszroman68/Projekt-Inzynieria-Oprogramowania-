﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace MateuszRoman_sklepZCzesciami
{
    public partial class Form2 : Form
    {
        //public List<Czesc> listCzesc = new List<Czesc>();

        public Form2()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {



            if (numericUpDown1.Value == 0) // zabezpieczenie przed dodaniem pola z wartością domyślną
            {
                numericUpDown1.Value = 10;
                MessageBox.Show("Wprowadzono korekte ceny!");
            }
            if (checkBox2.Checked != true) // na czesci niskiej jakosci rok gwarancji
            {
                numericUpDown6.Value = 1;
            }

            if (numericUpDown4.Value < 1950) // jesli samochód jest za stary program usuwa te czesc
            {
                MessageBox.Show("Brak czesci dla tak starych aut !");
                textBox1.Text = "XXXXXXX";
                textBox2.Text = "XXXXXXX";
                textBox3.Text = "XXXXXXX";
                numericUpDown1.Value = 111;
                numericUpDown2.Value = 111;
                numericUpDown3.Value = 1;
                numericUpDown4.Value = 2000;
                checkBox1.Checked = true;
                textBox4.Text = "XXXXXXX";
                checkBox4.Checked = false;
                numericUpDown5.Value = 111;
                checkBox2.Checked = true;
                checkBox3.Checked = false;
                numericUpDown6.Value = 2;
            }

            Czesc czz = new CzescZamienna(textBox1.Text,
                textBox2.Text,
                textBox3.Text,
                Convert.ToInt32( numericUpDown1.Value),
                Convert.ToInt32( numericUpDown2.Value),
                Convert.ToInt32( numericUpDown3.Value), 
                Convert.ToInt32( numericUpDown4.Value),
                checkBox1.Checked,
                textBox4.Text,
                checkBox4.Checked,
                dateTimePicker1.Value,
                (Bitmap)pictureBox1.Image,
                Convert.ToInt32(numericUpDown5.Value),
                checkBox3.Checked,
                checkBox3.Checked,
                Convert.ToInt32 (numericUpDown6.Value));
            
            czz.Write(listBox1,pictureBox1);

            Czesc.listCzesc.Add(new CzescZamienna(textBox1.Text, textBox2.Text, textBox3.Text, Convert.ToInt32(numericUpDown1.Value),
                Convert.ToInt32(numericUpDown2.Value), Convert.ToInt32(numericUpDown3.Value), Convert.ToInt32(numericUpDown4.Value),
                checkBox1.Checked, textBox4.Text, checkBox4.Checked, dateTimePicker1.Value, (Bitmap)pictureBox1.Image, Convert.ToInt32(numericUpDown5.Value),
                checkBox3.Checked, checkBox3.Checked, Convert.ToInt32(numericUpDown6.Value)));

            

        }
       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown1.Maximum =10000;
            numericUpDown1.Minimum = 1;
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown3.DecimalPlaces = 2;
            numericUpDown3.Maximum = (decimal)10.0f;
            numericUpDown3.Minimum = (decimal)0.5f;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown2.Maximum = int.MaxValue;
            numericUpDown2.Minimum = 0;

        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown4.Maximum = 2023;
          //  numericUpDown4.Minimum = 1950;
        }

        public void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                string fileName = openFileDialog1.FileName;
                Bitmap bitmap = new Bitmap(fileName);              
                pictureBox1.Image = bitmap; 
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Wahacz";
            textBox2.Text = "Mercedes";
            textBox3.Text = "W123";
            numericUpDown1.Value = 150;
            numericUpDown2.Value = 777;
            numericUpDown3.Value = 2;
            numericUpDown4.Value = 1995;
            checkBox1.Checked = true;
            textBox4.Text = "zawieszenie";
            checkBox4.Checked = false;
            numericUpDown5.Value = 938;
            checkBox2.Checked = true;
            checkBox3.Checked = false;
            numericUpDown6.Value = 2;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName))
                    foreach (CzescZamienna rw in Czesc.listCzesc)
                        rw.Serialize(sw);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                    while (!sr.EndOfStream)
                    {
                        string header = sr.ReadLine();
                        if (header == "== Czesc zamienna ==") new CzescZamienna(sr);
                    }
            if (Czesc.listCzesc.Count > 0)
            {
                for (int i = 0; i < Czesc.listCzesc.Count 
                    ; i++)
                {
                    Czesc.listCzesc[i].Write(listBox1, pictureBox1);
                }
              
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    
}
