﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace MateuszRoman_sklepZCzesciami
{
    abstract public class Czesc
    {
        protected string partName;
        protected string brandName;
        protected string model;
        protected int price;
        protected int ID;
        protected float engineCapacity;
        protected int yearOfProduction;
        protected bool serviceStation; // warsztaty samochodowe kupuja po innej cenie niz klienci detaliczni
        protected  string category;
        protected bool tenPercentDiscount;
        protected DateTime dOfPP; // date of part production
        protected Bitmap photo;

       

        public Czesc()
        {
            this.partName = "-";
            this.brandName = "-";
            this.model = "-";
            this.price = 0;
            this.ID = 0;
            this.engineCapacity = 0.0f;
            this.yearOfProduction = 0;
            this.serviceStation = false;
            this.category = "-";
            this.tenPercentDiscount = false;
            this.dOfPP = new DateTime(2000, 01, 01);
        }
        public Czesc(string partName, string brandName, string model, int price, int ID, float engineCapacity, int yearOfProduction, bool serviceStation, string category , bool tenPercentDiscount,DateTime dOfPP,Bitmap photo) 
        {
            this.partName = partName;
            this.brandName = brandName;
            this.model = model;
            this.price = price;
            this.ID = ID;
            this.engineCapacity = engineCapacity;
            this.yearOfProduction = yearOfProduction;
            this.serviceStation = serviceStation;
            this.category = category;
            this.tenPercentDiscount = tenPercentDiscount;
            this.dOfPP = dOfPP;
            this.photo = photo;
        }


        public Czesc(Czesc cz) 
        {
            this.partName = cz.partName;
            this.brandName = cz.brandName;
            this.model = cz.model;
            this.price = cz.price;
            this.ID = cz.ID;
            this.engineCapacity = cz.engineCapacity;
            this.yearOfProduction = cz.yearOfProduction;
            this.serviceStation = cz.serviceStation;
            this.category = cz.category;
            this.tenPercentDiscount = cz.tenPercentDiscount;
            this.dOfPP = cz.dOfPP;
            this.photo = cz.photo;

        }

      

        public virtual void Write(ListBox lb, PictureBox pb)
        {
            lb.Items.Add("------------------");
            lb.Items.Add("Nazwa części: " + partName);
            lb.Items.Add("Marka: " + brandName);
            lb.Items.Add("Model: " + model);
            lb.Items.Add("cena: " + price);
            lb.Items.Add("ID: " + ID + UniqueNumber());
            lb.Items.Add("Pojemnosc silnika: " + engineCapacity);
            lb.Items.Add("Rok produkcji: " + yearOfProduction);
            lb.Items.Add("Czy warsztat: " + serviceStation);
            lb.Items.Add("Kategoria: " + category);
            lb.Items.Add("zniżka 10%: " + tenPercentDiscount);
            lb.Items.Add("Data produkcji części: " + dOfPP);
            pb.Image = photo;
          
           
        
        }

        ~Czesc()
        {
           
        }


        private int UniqueNumber() 
        {

            return 76437;
        }

        virtual public void Serialize(StreamWriter sw) { }
        virtual public void Deserialize(StreamReader sr) { }


        public static List<Czesc> listCzesc = new List<Czesc>();
    }
}
