﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MateuszRoman_sklepZCzesciami
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown1.Maximum = 1000;
            numericUpDown1.Minimum = 1;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown1.Maximum = int.MaxValue;
            numericUpDown1.Minimum = 1;
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown3.DecimalPlaces = 2;
            numericUpDown3.Maximum = (decimal)10.0f;
            numericUpDown3.Minimum = (decimal)0.5f;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown2.Maximum = int.MaxValue;
            numericUpDown2.Minimum = 0;
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown4.Maximum = 2023;
            numericUpDown4.Minimum = 1950;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Akcesoria acc = new Akcesoria(textBox1.Text,
                textBox2.Text,
                textBox3.Text, 
                Convert.ToInt32(numericUpDown1.Value),
                Convert.ToInt32(numericUpDown2.Value),
                Convert.ToInt32(numericUpDown3.Value),
                Convert.ToInt32(numericUpDown4.Value),
                checkBox1.Checked,
                textBox4.Text,
                checkBox4.Checked, 
                dateTimePicker1.Value,
                (Bitmap)pictureBox1.Image,
                textBox5.Text, 
                checkBox2.Checked,
                Convert.ToInt32(numericUpDown5.Value));

            acc.Write(listBox1,pictureBox1);

            Czesc.listCzesc.Add(new Akcesoria (textBox1.Text, textBox2.Text, textBox3.Text, Convert.ToInt32(numericUpDown1.Value),
                Convert.ToInt32(numericUpDown2.Value), Convert.ToInt32(numericUpDown3.Value), Convert.ToInt32(numericUpDown4.Value),
                checkBox1.Checked, textBox4.Text, checkBox4.Checked, dateTimePicker1.Value,
                (Bitmap)pictureBox1.Image, textBox5.Text, checkBox2.Checked, Convert.ToInt32(numericUpDown5.Value)));
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                Bitmap bitmap = new Bitmap(fileName);
                pictureBox1.Image = bitmap;
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Charger";
            textBox2.Text = "Baseus";
            textBox3.Text = "Grain";
            numericUpDown1.Value = 20;
            numericUpDown2.Value = 747;
            numericUpDown3.Value = 2;
            numericUpDown4.Value = 1995;
            checkBox1.Checked = true;
            textBox4.Text = "Akcesoria";
            checkBox4.Checked = false;
            textBox5.Text = "ładowarki";
            checkBox2.Checked = false;
            numericUpDown5.Value = 5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                    while (!sr.EndOfStream)
                    {
                        string header = sr.ReadLine();
                        if (header == "== Akcesoria ==") new Akcesoria(sr);
                    }
            if (Czesc.listCzesc.Count > 0)
            {
                for (int i = 0; i < Czesc.listCzesc.Count
                    ; i++)
                {
                    Czesc.listCzesc[i].Write(listBox1, pictureBox1);
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName))
                    foreach (Akcesoria tw in Czesc.listCzesc)
                        tw.Serialize(sw);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
