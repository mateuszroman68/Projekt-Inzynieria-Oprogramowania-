﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace MateuszRoman_sklepZCzesciami
{
    class Akcesoria: Czesc
    {
        protected string categoryOf;
        protected  bool universal;
        protected int markup;
        protected int[] recentRatings = new int [10];



        public Akcesoria() :base()
        {
            this.categoryOf = "-";
            this.universal = false;
            this.markup = 0;
            

        }
        public Akcesoria(string partName, string brandName, string model, int price, int ID, float engineCapacity,
            int yearOfProduction, bool serviceStation, string category, bool tenPercentDiscount, DateTime dOfPP,
            Bitmap photo, string categoryOf, bool universal, int markup) : base(partName, brandName, model, price,
                ID, engineCapacity, yearOfProduction, serviceStation, category, tenPercentDiscount, dOfPP,photo)
        {
            this.categoryOf = categoryOf;
            this.universal = universal;
            this.markup = markup;
            
        }
        public Akcesoria(Akcesoria acc): base(acc)
        {
            this.categoryOf = acc.category;
            this.universal = acc.universal;
            this.markup = acc.markup;
            
        }
        public Akcesoria(StreamReader sr)
        {
            Deserialize(sr);
            listCzesc.Add(this);
        }

        ~Akcesoria()
        { 
        }


        override public void Write(ListBox lb,PictureBox pb)
        {
            base.Write(lb,pb);
            lb.Items.Add("Category of accesories " + categoryOf);
            lb.Items.Add("universal accessories ? " + universal);
            lb.Items.Add("Markup : " + markup + Markup() + " zl");
            lb.Items.Add("Vat: " + Tax() + " zl");
            lb.Items.Add("recent Ratings: " + RecentRatings() +"/5") ;


        }
        
        private int Markup()//marża
        {
            Random rnd = new Random();
            int w = rnd.Next(2, 5);
            return price * 1/w;
               
        }

        private int Tax()
        {
            return (price  ) * 23 / 100;
        }

        private int RecentRatings() // srednia ocen produktu
        {
            int q = 0; 
            Random rnd = new Random();
            for (int i = 0; i < recentRatings.Length; i++)
            {
                recentRatings[i] = rnd.Next(1, 6);
                q = q + recentRatings[i];
                
            }

            q = (q / recentRatings.Length);
            return q;
        }
        private void SaveBmp(StreamWriter sw)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                photo.Save(ms, ImageFormat.Bmp);
                byte[] bytes = ms.ToArray();
                sw.WriteLine(Convert.ToBase64String(bytes, 0, bytes.Length));
            }
        }
        override public void Serialize(StreamWriter sw)
        {

            sw.WriteLine("== Akcesoria ==");
            sw.WriteLine(partName);
            sw.WriteLine(brandName);
            sw.WriteLine(model);
            sw.WriteLine(price);
            sw.WriteLine(ID);
            sw.WriteLine(engineCapacity);
            sw.WriteLine(yearOfProduction);
            sw.WriteLine(serviceStation);
            sw.WriteLine(category);
            sw.WriteLine(tenPercentDiscount);
            sw.WriteLine(dOfPP);
            sw.WriteLine(categoryOf);
            sw.WriteLine(universal);
            SaveBmp(sw);
           
           
            
        }
        override public void Deserialize(StreamReader sr)
        {

            partName = sr.ReadLine();
            brandName = sr.ReadLine();
            model = sr.ReadLine();
            price = Convert.ToInt32(sr.ReadLine());
            ID = Convert.ToInt32(sr.ReadLine());
            engineCapacity = Convert.ToInt32(sr.ReadLine());
            yearOfProduction = Convert.ToInt32(sr.ReadLine());
            serviceStation = Convert.ToBoolean(sr.ReadLine());
            category = sr.ReadLine();
            tenPercentDiscount = Convert.ToBoolean(sr.ReadLine());
            dOfPP = Convert.ToDateTime(sr.ReadLine());
            categoryOf = sr.ReadLine();
            universal = Convert.ToBoolean(sr.ReadLine());
            photo = LoadBmp(sr);


            
        }
        private Bitmap LoadBmp(StreamReader sr)
        {
            byte[] bytes = Convert.FromBase64String(sr.ReadLine());
            using (MemoryStream ms = new MemoryStream(bytes))
                return new Bitmap(ms);
        }

    }
}
